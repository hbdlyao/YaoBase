///////////////////////////////////////////////////////////
//  CHvdcDefs.cpp
//  Implementation of the Class struct_BGXB
//  Created on:      24-3��-2017 19:27:09
//  Original author: Administrator
///////////////////////////////////////////////////////////

#include "gbHead_Def.h"












