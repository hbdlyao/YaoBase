#pragma once


#include "CmcCalOneDot.h"

/**
 * ����· �ӵؼ���
 */
class CmcCalGroundLine : public CmcCalOneDot
{


public:

protected:
	virtual void UpdateY();
};
