#pragma once


#include "CmcCalculate.h"

class CmcCalTwoDot : public CmcCalculate
{

};
