///////////////////////////////////////////////////////////
//  CmcDevOneDot.cpp
//  Implementation of the Class CmcDevOneDot
//  Created on:      13-4��-2017 13:15:20
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CmcDevOneDot.h"




void CmcDevOneDot::Init(){

	SetDotCount(1);
}