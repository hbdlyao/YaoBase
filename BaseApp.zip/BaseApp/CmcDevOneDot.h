#pragma once


#include "CmcDevBase.h"

/**
 * һ�˵��豸
 */
class CmcDevOneDot : public CmcDevBase
{

protected:
	virtual void Init();

};
