///////////////////////////////////////////////////////////
//  CmcDevTwoDot.cpp
//  Implementation of the Class CmcDevTwoDot
//  Created on:      13-4��-2017 13:15:25
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CmcDevTwoDot.h"




void CmcDevTwoDot::Init(){

	SetDotCount(2);
}