///////////////////////////////////////////////////////////
//  CmcHVDC.cpp
//  Implementation of the Class CmcHVDC
//  Created on:      23-3��-2017 16:24:58
//  Original author: Administrator
///////////////////////////////////////////////////////////

#include "CmcHVDC.h"


CmcHVDC::CmcHVDC(){

}



CmcHVDC::~CmcHVDC(){

}



CmcHVDC::CmcHVDC(const CmcHVDC& theCmcHVDC){

}