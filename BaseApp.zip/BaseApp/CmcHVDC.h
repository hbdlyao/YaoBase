#pragma once

#include "CPowerGrid.h"

class CmcHVDC : public CPowerGrid
{

public:
	CmcHVDC();
	virtual ~CmcHVDC();
	CmcHVDC(const CmcHVDC& theCmcHVDC);

};

