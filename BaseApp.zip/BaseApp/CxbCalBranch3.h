///////////////////////////////////////////////////////////
//  CxbCalBranch3.h
//  Implementation of the Class CxbCalBranch3
//  Created on:      13-4��-2017 13:54:25
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_405EF0C3_AC93_42fa_82D1_CF31DE1A18C6__INCLUDED_)
#define EA_405EF0C3_AC93_42fa_82D1_CF31DE1A18C6__INCLUDED_

#include "CxbCalTwoDot.h"

class CxbCalBranch3 : public CxbCalTwoDot
{

protected:
	virtual void UpdateY();

};
#endif // !defined(EA_405EF0C3_AC93_42fa_82D1_CF31DE1A18C6__INCLUDED_)
