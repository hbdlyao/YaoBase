///////////////////////////////////////////////////////////
//  CxbCalDCF.h
//  Implementation of the Class CxbCalDCF
//  Created on:      05-4��-2017 18:32:09
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_9ACDB07F_4B0F_4900_8A8D_3935DE6479A6__INCLUDED_)
#define EA_9ACDB07F_4B0F_4900_8A8D_3935DE6479A6__INCLUDED_

#include "CxbCalculate.h"

class CxbCalDCF : public CxbCalculate
{

protected:
	virtual void UpdateY();
};


#endif // !defined(EA_9ACDB07F_4B0F_4900_8A8D_3935DE6479A6__INCLUDED_)
