///////////////////////////////////////////////////////////
//  CxbCalMetalLine.h
//  Implementation of the Class CxbCalMetalLine
//  Created on:      05-4��-2017 18:32:45
//  Original author: Administrator
///////////////////////////////////////////////////////////

#if !defined(EA_222930FA_1FFE_4cca_B581_56F508AAFB25__INCLUDED_)
#define EA_222930FA_1FFE_4cca_B581_56F508AAFB25__INCLUDED_

#include "CxbCalDcLine.h"

/**
 * ��������
 */
class CxbCalMetalLine : public CxbCalDcLine
{

};
#endif // !defined(EA_222930FA_1FFE_4cca_B581_56F508AAFB25__INCLUDED_)
