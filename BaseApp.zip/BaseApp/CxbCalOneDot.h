///////////////////////////////////////////////////////////
//  CxbCalOneDot.h
//  Implementation of the Class CxbCalOneDot
//  Created on:      05-4��-2017 18:31:56
//  Original author: Administrator
///////////////////////////////////////////////////////////

#if !defined(EA_A00BA6C1_D91B_4183_95AF_CE02940C554C__INCLUDED_)
#define EA_A00BA6C1_D91B_4183_95AF_CE02940C554C__INCLUDED_


#include "CxbCalculate.h"

class CxbCalOneDot : public CxbCalculate
{

};
#endif // !defined(EA_A00BA6C1_D91B_4183_95AF_CE02940C554C__INCLUDED_)
