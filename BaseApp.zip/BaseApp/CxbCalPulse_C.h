///////////////////////////////////////////////////////////
//  CxbCalPulse_C.h
//  Implementation of the Class CxbCalPulse_C
//  Created on:      05-4��-2017 18:33:11
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_2F61274A_9738_4eec_8BD0_7A019796BD0E__INCLUDED_)
#define EA_2F61274A_9738_4eec_8BD0_7A019796BD0E__INCLUDED_

#include "CxbCalShunt.h"

class CxbCalPulse_C : public CxbCalShunt
{

};
#endif // !defined(EA_2F61274A_9738_4eec_8BD0_7A019796BD0E__INCLUDED_)
