///////////////////////////////////////////////////////////
//  CxbCalShunt.h
//  Implementation of the Class CxbCalShunt
//  Created on:      05-4��-2017 18:32:21
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_88EB848B_339E_45f6_AFC9_A96CA03BAF30__INCLUDED_)
#define EA_88EB848B_339E_45f6_AFC9_A96CA03BAF30__INCLUDED_

#include "CxbCalOneDot.h"

class CxbCalShunt : public CxbCalOneDot
{

public:

protected:
	virtual void UpdateY();
};
#endif // !defined(EA_88EB848B_339E_45f6_AFC9_A96CA03BAF30__INCLUDED_)
