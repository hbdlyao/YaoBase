///////////////////////////////////////////////////////////
//  CxbCalXf2_C.h
//  Implementation of the Class CxbCalXf2_C
//  Created on:      13-4��-2017 13:54:26
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_085DAB7F_7707_4ad2_AD6A_7D1AD6692CAA__INCLUDED_)
#define EA_085DAB7F_7707_4ad2_AD6A_7D1AD6692CAA__INCLUDED_

#include "CxbCalShunt.h"

class CxbCalXf2_C : public CxbCalShunt
{

};
#endif // !defined(EA_085DAB7F_7707_4ad2_AD6A_7D1AD6692CAA__INCLUDED_)
