///////////////////////////////////////////////////////////
//  CxbDevGround.h
//  Implementation of the Class CxbDevGround
//  Created on:      07-4��-2017 11:55:58
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_12FC0160_D9F1_4a65_99F9_017256F7A04E__INCLUDED_)
#define EA_12FC0160_D9F1_4a65_99F9_017256F7A04E__INCLUDED_

#include "CxbDevShunt.h"

/**
 * �ӵص���
 */
class CxbDevGround : public CxbDevShunt
{

};
#endif // !defined(EA_12FC0160_D9F1_4a65_99F9_017256F7A04E__INCLUDED_)
