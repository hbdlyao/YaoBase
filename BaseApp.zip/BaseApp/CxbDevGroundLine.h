///////////////////////////////////////////////////////////
//  CxbDevGroundLine.h
//  Implementation of the Class CxbDevGroundLine
//  Created on:      05-4��-2017 16:58:43
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_8113989A_E55C_4a46_A27D_69B6F2ACC9B6__INCLUDED_)
#define EA_8113989A_E55C_4a46_A27D_69B6F2ACC9B6__INCLUDED_

#include "CxbDevDcLine.h"

/**
 * �ӵؼ���
 */
class CxbDevGroundLine : public CxbDevDcLine
{

};
#endif // !defined(EA_8113989A_E55C_4a46_A27D_69B6F2ACC9B6__INCLUDED_)
