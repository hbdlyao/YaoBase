///////////////////////////////////////////////////////////
//  CxbDevMetalLine.h
//  Implementation of the Class CxbDevMetalLine
//  Created on:      05-4��-2017 16:58:39
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_8BEA934A_BF07_4e48_9794_D3B58A0589A4__INCLUDED_)
#define EA_8BEA934A_BF07_4e48_9794_D3B58A0589A4__INCLUDED_

#include "CxbDevDcLine.h"

/**
 * ��������
 */
class CxbDevMetalLine : public CxbDevDcLine
{

};
#endif // !defined(EA_8BEA934A_BF07_4e48_9794_D3B58A0589A4__INCLUDED_)
