///////////////////////////////////////////////////////////
//  CxbDevOneDot.cpp
//  Implementation of the Class CxbDevOneDot
//  Created on:      12-4��-2017 12:00:13
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CxbDevOneDot.h"




void CxbDevOneDot::Init(){

	SetDotCount(1);
}