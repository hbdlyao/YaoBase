///////////////////////////////////////////////////////////
//  CxbDevPbDkq.h
//  Implementation of the Class CxbDevPbDkq
//  Created on:      05-4��-2017 16:59:44
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_24107975_868F_41c6_94D6_A9B97A875814__INCLUDED_)
#define EA_24107975_868F_41c6_94D6_A9B97A875814__INCLUDED_

#include "CxbDevBranch.h"

/**
 * ƽ���翹��
 */
class CxbDevPbDkq : public CxbDevBranch
{

};
#endif // !defined(EA_24107975_868F_41c6_94D6_A9B97A875814__INCLUDED_)
