///////////////////////////////////////////////////////////
//  CxbDevTwoDot.cpp
//  Implementation of the Class CxbDevTwoDot
//  Created on:      12-4��-2017 12:00:20
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CxbDevTwoDot.h"




void CxbDevTwoDot::Init(){

	SetDotCount(2);
}