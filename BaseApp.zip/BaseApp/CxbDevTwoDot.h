///////////////////////////////////////////////////////////
//  CxbDevTwoDot.h
//  Implementation of the Class CxbDevTwoDot
//  Created on:      12-4��-2017 12:00:20
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_8E88760C_D6CE_419f_A916_6E2E357A1B1E__INCLUDED_)
#define EA_8E88760C_D6CE_419f_A916_6E2E357A1B1E__INCLUDED_

#include "CxbDevBase.h"

/**
 * ˫�˵��豸
 */
class CxbDevTwoDot : public CxbDevBase
{

protected:
	virtual void Init();

};
#endif // !defined(EA_8E88760C_D6CE_419f_A916_6E2E357A1B1E__INCLUDED_)
