///////////////////////////////////////////////////////////
//  CxbResult.cpp
//  Implementation of the Class CxbResult
//  Created on:      05-4��-2017 18:22:15
//  Original author: Administrator
///////////////////////////////////////////////////////////

#include "CxbResult.h"

CxbResult::~CxbResult()
{
	Clear();
}

void CxbResult::Init()
{
}

void CxbResult::Clear()
{
}


void CxbResult::InitMatrix()
{
}
