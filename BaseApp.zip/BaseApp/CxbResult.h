///////////////////////////////////////////////////////////
//  CxbResult.h
//  Implementation of the Class CxbResult
//  Created on:      05-4��-2017 18:22:15
//  Original author: Administrator
///////////////////////////////////////////////////////////

#if !defined(EA_49F778C6_2FB9_483f_9677_BE3DA383F395__INCLUDED_)
#define EA_49F778C6_2FB9_483f_9677_BE3DA383F395__INCLUDED_

class CxbResult
{
public :
	virtual ~CxbResult() ;

	void Init();

	void Clear();

	void InitMatrix();

};
#endif // !defined(EA_49F778C6_2FB9_483f_9677_BE3DA383F395__INCLUDED_)
