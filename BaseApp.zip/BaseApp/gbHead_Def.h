#pragma once

#include "CMyDefs.h"

#include "CHvdcDefs.h"
#include "CmcDefs.h"
#include "CxbDefs.h"