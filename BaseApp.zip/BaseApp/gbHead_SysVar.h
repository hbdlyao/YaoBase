#pragma once

#include "CMyMvcs.h"
#include "CMyRw.h"
#include "CMyVars.h"
#include "CMyInitApp.h"



