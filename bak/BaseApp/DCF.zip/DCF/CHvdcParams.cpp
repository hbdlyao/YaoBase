///////////////////////////////////////////////////////////
//  CHvdcParams.cpp
//  Implementation of the Class CHvdcParams
//  Created on:      24-3��-2017 20:55:58
//  Original author: Administrator
///////////////////////////////////////////////////////////

#include "CHvdcParams.h"

string CHvdcParams::ProjectName = "Hvdc_Project";

int CHvdcParams::ProjectID = 1;
int CHvdcParams::mcStationCount=2;
int CHvdcParams::xbStationCount = 2;
int CHvdcParams::hMax = 60;

double CHvdcParams::Frequence = 60;

void CHvdcParams::Init()
{
	//

}
