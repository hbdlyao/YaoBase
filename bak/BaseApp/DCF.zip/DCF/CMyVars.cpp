///////////////////////////////////////////////////////////
//  CMyVars.cpp
//  Implementation of the Class CMyVars
//  Created on:      22-3��-2017 18:24:25
//  Original author: Administrator
///////////////////////////////////////////////////////////

#include "CMyVars.h"

#include "CMyParams.h"
#include "gbHead_SysVar.h"


///////////////////////////////////
void CMyVars::Release()
{
}



void CMyVars::Clear()
{
}

void CMyVars::Init(){

	//gbPasVar:=TPasVar.Create;
	//gbPasVar.InitSelf;
}