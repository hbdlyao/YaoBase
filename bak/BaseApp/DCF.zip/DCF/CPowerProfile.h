///////////////////////////////////////////////////////////
//  CPowerProfile.h
//  Implementation of the Class CPowerProfile
//  Created on:      29-3��-2017 22:36:32
//  Original author: Administrator
///////////////////////////////////////////////////////////

#if !defined(EA_8BA55D66_0E12_4be4_98D8_62C258569774__INCLUDED_)
#define EA_8BA55D66_0E12_4be4_98D8_62C258569774__INCLUDED_

#include "CPowerMath.h"
#include "CPowerGrid.h"


class CPowerProfile : public CPower_YU_I
{
public:
	int NodeCount;
	int StaCount;

};
#endif // !defined(EA_8BA55D66_0E12_4be4_98D8_62C258569774__INCLUDED_)
