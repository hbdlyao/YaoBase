#pragma once

#include "CmcCalOneDot.h"

class CmcCalGround : public CmcCalOneDot
{

public:

protected:
	virtual void UpdateY();

};
