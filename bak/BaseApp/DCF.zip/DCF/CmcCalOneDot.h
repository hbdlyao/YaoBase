#pragma once


#include "CmcCalculate.h"

class CmcCalOneDot : public CmcCalculate
{

};
