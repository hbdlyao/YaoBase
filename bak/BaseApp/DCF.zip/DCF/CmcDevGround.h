#pragma once

#include "CmcDevShunt.h"

class CmcDevGround : public CmcDevShunt
{

public:

};
