#pragma once

#include "CmcDevDcLine.h"

class CmcDevMetalLine : public CmcDevDcLine
{

};

