#pragma once


#include "CmcDevBase.h"

/**
 * ˫�˵��豸
 */
class CmcDevTwoDot : public CmcDevBase
{

protected:
	virtual void Init();

};
