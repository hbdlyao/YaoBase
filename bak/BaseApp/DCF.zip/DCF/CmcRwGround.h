///////////////////////////////////////////////////////////
//  CmcRwGround.h
//  Implementation of the Class CmcRwGround
//  Created on:      18-4��-2017 22:05:43
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_6745D2EF_EDD5_4998_8FBF_7A455ADEFE06__INCLUDED_)
#define EA_6745D2EF_EDD5_4998_8FBF_7A455ADEFE06__INCLUDED_

#include "CmcRwShunt.h"

class CmcRwGround : public CmcRwShunt
{

};
#endif // !defined(EA_6745D2EF_EDD5_4998_8FBF_7A455ADEFE06__INCLUDED_)
