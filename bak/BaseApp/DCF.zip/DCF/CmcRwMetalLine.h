///////////////////////////////////////////////////////////
//  CmcRwMetalLine.h
//  Implementation of the Class CmcRwMetalLine
//  Created on:      18-4��-2017 22:05:49
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_C9453213_2E6A_4dd5_B44A_558AB36503BF__INCLUDED_)
#define EA_C9453213_2E6A_4dd5_B44A_558AB36503BF__INCLUDED_

#include "CmcRwDcLine.h"

class CmcRwMetalLine : public CmcRwDcLine
{

};
#endif // !defined(EA_C9453213_2E6A_4dd5_B44A_558AB36503BF__INCLUDED_)
