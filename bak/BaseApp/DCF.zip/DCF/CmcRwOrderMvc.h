///////////////////////////////////////////////////////////
//  CmcRwOrderMvc.h
//  Implementation of the Class CmcRwOrderMvc
//  Created on:      18-4��-2017 22:36:22
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_2329C3EB_F3AD_46e9_80FA_F0DBFD7B8ECE__INCLUDED_)
#define EA_2329C3EB_F3AD_46e9_80FA_F0DBFD7B8ECE__INCLUDED_

#include "CRwMvc.h"
#include "CmcOrder.h"

class CmcRwOrderMvc : public CRwMvcAccess
{
protected:
	CmcOrder * pOrder;
public:
	void Init(CmcOrder* vOrder);

	void doLoad();
	void doSave();
};
#endif // !defined(EA_2329C3EB_F3AD_46e9_80FA_F0DBFD7B8ECE__INCLUDED_)
