///////////////////////////////////////////////////////////
//  CmcRwTwo.h
//  Implementation of the Class CmcRwTwo
//  Created on:      18-4��-2017 20:24:54
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_D53EB87A_8A7C_430e_A756_F40ED8B991E7__INCLUDED_)
#define EA_D53EB87A_8A7C_430e_A756_F40ED8B991E7__INCLUDED_

#include "CmcRw.h"


class CmcRwTwo : public CmcRw
{

protected:
	void doLoad(CmcDevBase* vDevice) override;
	void doSave(CmcDevBase* vDevice) override;

};
#endif // !defined(EA_D53EB87A_8A7C_430e_A756_F40ED8B991E7__INCLUDED_)
