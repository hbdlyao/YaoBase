///////////////////////////////////////////////////////////
//  CxbCalBranch3.cpp
//  Implementation of the Class CxbCalBranch3
//  Created on:      13-4��-2017 13:54:25
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CxbCalBranch3.h"




void CxbCalBranch3::UpdateY(){

}