///////////////////////////////////////////////////////////
//  CxbCalCouple_C.h
//  Implementation of the Class CxbCalCouple_C
//  Created on:      05-4��-2017 18:33:17
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_1F55AAA9_3E4F_4dcf_8590_AD03D8FBD5BA__INCLUDED_)
#define EA_1F55AAA9_3E4F_4dcf_8590_AD03D8FBD5BA__INCLUDED_

#include "CxbCalShunt.h"

class CxbCalCouple_C : public CxbCalShunt
{

};
#endif // !defined(EA_1F55AAA9_3E4F_4dcf_8590_AD03D8FBD5BA__INCLUDED_)
