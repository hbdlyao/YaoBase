///////////////////////////////////////////////////////////
//  CxbCalDCF_RLC.h
//  Implementation of the Class CxbCalDCF_RLC
//  Created on:      20-4��-2017 21:39:14
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_A9ADC839_E954_4e42_88E0_D38E2FAE5401__INCLUDED_)
#define EA_A9ADC839_E954_4e42_88E0_D38E2FAE5401__INCLUDED_

#include "CxbCalBranch.h"

class CxbCalDCF_RLC : public CxbCalBranch
{

};
#endif // !defined(EA_A9ADC839_E954_4e42_88E0_D38E2FAE5401__INCLUDED_)
