///////////////////////////////////////////////////////////
//  CxbCalGround.h
//  Implementation of the Class CxbCalGround
//  Created on:      07-4��-2017 12:00:51
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_E2F1E773_4CED_4c80_8117_A59ACA715BFC__INCLUDED_)
#define EA_E2F1E773_4CED_4c80_8117_A59ACA715BFC__INCLUDED_

#include "CxbCalShunt.h"

class CxbCalGround : public CxbCalShunt
{

};
#endif // !defined(EA_E2F1E773_4CED_4c80_8117_A59ACA715BFC__INCLUDED_)
