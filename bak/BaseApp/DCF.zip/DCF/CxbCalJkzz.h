///////////////////////////////////////////////////////////
//  CxbCalJkzz.h
//  Implementation of the Class CxbCalJkzz
//  Created on:      13-4��-2017 13:54:26
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_51E0C33D_2318_4bb2_B954_B5589D27A2CD__INCLUDED_)
#define EA_51E0C33D_2318_4bb2_B954_B5589D27A2CD__INCLUDED_

#include "CxbCalBranch3.h"

class CxbCalJkzz : public CxbCalBranch3
{

};
#endif // !defined(EA_51E0C33D_2318_4bb2_B954_B5589D27A2CD__INCLUDED_)
