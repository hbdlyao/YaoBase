///////////////////////////////////////////////////////////
//  CxbCalPbDkq.h
//  Implementation of the Class CxbCalPbDkq
//  Created on:      05-4��-2017 21:52:40
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_BCB3DA36_8234_4148_9B7B_91FB389AF7C6__INCLUDED_)
#define EA_BCB3DA36_8234_4148_9B7B_91FB389AF7C6__INCLUDED_

#include "CxbCalBranch.h"

class CxbCalPbDkq : public CxbCalBranch
{

};
#endif // !defined(EA_BCB3DA36_8234_4148_9B7B_91FB389AF7C6__INCLUDED_)
