#pragma once

#include "CxbCalOneDot.h"

class CxbCalShunt : public CxbCalOneDot
{

public:

protected:
	virtual void UpdateY();
};
