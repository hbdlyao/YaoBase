///////////////////////////////////////////////////////////
//  CxbCalTrap.h
//  Implementation of the Class CxbCalTrap
//  Created on:      13-4��-2017 13:54:26
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_D82062DE_1C1F_45d0_9310_D422AA80E489__INCLUDED_)
#define EA_D82062DE_1C1F_45d0_9310_D422AA80E489__INCLUDED_

#include "CxbCalBranch3.h"

class CxbCalTrap : public CxbCalBranch3
{

};
#endif // !defined(EA_D82062DE_1C1F_45d0_9310_D422AA80E489__INCLUDED_)
