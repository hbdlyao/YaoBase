///////////////////////////////////////////////////////////
//  CxbCalTwoDot.h
//  Implementation of the Class CxbCalTwoDot
//  Created on:      05-4��-2017 18:32:02
//  Original author: Administrator
///////////////////////////////////////////////////////////

#if !defined(EA_048127E9_995E_4b82_90D6_EEAC282074D3__INCLUDED_)
#define EA_048127E9_995E_4b82_90D6_EEAC282074D3__INCLUDED_


#include "CxbCalculate.h"

class CxbCalTwoDot : public CxbCalculate
{

};
#endif // !defined(EA_048127E9_995E_4b82_90D6_EEAC282074D3__INCLUDED_)
