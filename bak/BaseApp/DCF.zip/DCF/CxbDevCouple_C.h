///////////////////////////////////////////////////////////
//  CxbDevCouple_C.h
//  Implementation of the Class CxbDevCouple_C
//  Created on:      05-4��-2017 17:00:25
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_F48C9AAD_D18E_4edc_ADAB_3CBA9E092F87__INCLUDED_)
#define EA_F48C9AAD_D18E_4edc_ADAB_3CBA9E092F87__INCLUDED_

#include "CxbDevShunt.h"

/**
 * ��ϵ���
 */
class CxbDevCouple_C : public CxbDevShunt
{

};
#endif // !defined(EA_F48C9AAD_D18E_4edc_ADAB_3CBA9E092F87__INCLUDED_)
