///////////////////////////////////////////////////////////
//  CxbDevDCF.h
//  Implementation of the Class CxbDevDCF
//  Created on:      05-4��-2017 16:59:04
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_B1BBC94F_C119_49e3_9B4A_B9969566C593__INCLUDED_)
#define EA_B1BBC94F_C119_49e3_9B4A_B9969566C593__INCLUDED_

#include "CxbDev_Tree.h"

//������
#include "CComplex.h"
#include "gbHead_Def.h"
#include "CRand.h"
#include "CxbDCFData.h"


/**
* ֱ���˲���
*/
class CxbDevDCF : public CxbDev_Tree
{
protected:
	/**
	 * ����
	 */
	int DCFType;

	double MaxFreqDelta=0;
	double MinFreqDelta=0;


public:
	int SampleNum = 0;

	int GetDCFType();
	void SetDCFType(int newVal);

	//
	void Prepare_hRLC() override;

public:
	double GetMaxFreqDelta();
	void SetMaxFreqDelta(double newVal);
	double GetMinFreqDelta();
	void SetMinFreqDelta(double newVal);
	int GetSampleNum();
	void SetSampleNum(int newVal);
};
#endif // !defined(EA_B1BBC94F_C119_49e3_9B4A_B9969566C593__INCLUDED_)
