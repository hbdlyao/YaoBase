///////////////////////////////////////////////////////////
//  CxbDevMonitor.h
//  Implementation of the Class CxbDevMonitor
//  Created on:      18-4��-2017 9:45:53
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_E654BC48_A9EE_40e0_8C52_0636C387E6BC__INCLUDED_)
#define EA_E654BC48_A9EE_40e0_8C52_0636C387E6BC__INCLUDED_

#include "CxbDev_Tree.h"

class CxbDevMonitor : public CxbDev_Tree
{

};
#endif // !defined(EA_E654BC48_A9EE_40e0_8C52_0636C387E6BC__INCLUDED_)
