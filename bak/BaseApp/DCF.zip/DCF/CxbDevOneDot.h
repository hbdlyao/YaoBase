///////////////////////////////////////////////////////////
//  CxbDevOneDot.h
//  Implementation of the Class CxbDevOneDot
//  Created on:      12-4��-2017 12:00:13
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_CA2E0716_609C_4ab6_BC30_668E9A53228F__INCLUDED_)
#define EA_CA2E0716_609C_4ab6_BC30_668E9A53228F__INCLUDED_

#include "CxbDevBase.h"

/**
 * һ�˵��豸
 */
class CxbDevOneDot : public CxbDevBase
{

protected:
	virtual void Init();

};
#endif // !defined(EA_CA2E0716_609C_4ab6_BC30_668E9A53228F__INCLUDED_)
