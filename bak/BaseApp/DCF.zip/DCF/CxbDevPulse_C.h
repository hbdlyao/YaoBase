///////////////////////////////////////////////////////////
//  CxbDevPulse_C.h
//  Implementation of the Class CxbDevPulse_C
//  Created on:      05-4��-2017 17:00:30
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_E503B08E_ADE3_42e4_97D0_DC268E1251C1__INCLUDED_)
#define EA_E503B08E_ADE3_42e4_97D0_DC268E1251C1__INCLUDED_

#include "CxbDevShunt.h"

/**
 * �弤����
 */
class CxbDevPulse_C : public CxbDevShunt
{

};
#endif // !defined(EA_E503B08E_ADE3_42e4_97D0_DC268E1251C1__INCLUDED_)
