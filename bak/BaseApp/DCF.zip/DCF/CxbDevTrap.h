///////////////////////////////////////////////////////////
//  CxbDevTrap.h
//  Implementation of the Class CxbDevTrap
//  Created on:      18-4��-2017 9:45:45
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_C864F772_1D2A_4682_A63C_2490BCB3AC15__INCLUDED_)
#define EA_C864F772_1D2A_4682_A63C_2490BCB3AC15__INCLUDED_

#include "CxbDev_Tree.h"

class CxbDevTrap : public CxbDev_Tree
{

};
#endif // !defined(EA_C864F772_1D2A_4682_A63C_2490BCB3AC15__INCLUDED_)
