///////////////////////////////////////////////////////////
//  CxbDevXf_C.h
//  Implementation of the Class CxbDevXf_C
//  Created on:      05-4��-2017 17:00:17
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_A0D4C28B_EDB8_4d9c_838D_A444BBC30D29__INCLUDED_)
#define EA_A0D4C28B_EDB8_4d9c_838D_A444BBC30D29__INCLUDED_

#include "CxbDevShunt.h"

/**
 * ��ѹ����ɢ����
 */
class CxbDevXf_C : public CxbDevShunt
{

};
#endif // !defined(EA_A0D4C28B_EDB8_4d9c_838D_A444BBC30D29__INCLUDED_)
