///////////////////////////////////////////////////////////
//  CxbRwOne.h
//  Implementation of the Class CxbRwOne
//  Created on:      18-4��-2017 17:11:01
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_C57A77AE_48C4_47b2_B698_08797F5598B9__INCLUDED_)
#define EA_C57A77AE_48C4_47b2_B698_08797F5598B9__INCLUDED_

#include "CxbRw.h"

class CxbRwOne : public CxbRw
{

protected:
	void doLoad(CxbDevBase * vDevice) override;
	void doSave(CxbDevBase * vDevice) override;

};
#endif // !defined(EA_C57A77AE_48C4_47b2_B698_08797F5598B9__INCLUDED_)
