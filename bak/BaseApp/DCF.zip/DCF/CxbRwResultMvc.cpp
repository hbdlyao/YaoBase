///////////////////////////////////////////////////////////
//  CxbRwResultMvc.cpp
//  Implementation of the Class CxbRwResultMvc
//  Created on:      18-4��-2017 22:56:22
//  Original author: open2
///////////////////////////////////////////////////////////

#include "CxbRwResultMvc.h"




void CxbRwResultMvc::Init(CxbResult* vRes)
{

	pResult = vRes;
}


void CxbRwResultMvc::doLoad()
{

}


void CxbRwResultMvc::doSave()
{

}