///////////////////////////////////////////////////////////
//  CxbRwTwo.h
//  Implementation of the Class CxbRwTwo
//  Created on:      18-4��-2017 17:11:07
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_48147E10_C6DB_46d7_8847_85ED29C29946__INCLUDED_)
#define EA_48147E10_C6DB_46d7_8847_85ED29C29946__INCLUDED_

#include "CxbRw.h"

class CxbRwTwo : public CxbRw
{

protected:
	void doLoad(CxbDevBase * vDevice) override;
	void doSave(CxbDevBase * vDevice) override;
};
#endif // !defined(EA_48147E10_C6DB_46d7_8847_85ED29C29946__INCLUDED_)
